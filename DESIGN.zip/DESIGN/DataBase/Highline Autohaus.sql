use Highline_Autohaus;
INSERT INTO dealership (address, city, state, phone, email)
VALUES
  ('123 Main Street', 'Mumbai', 'Maharashtra', '+91-1234567890', 'info@highlineautohaus.com'),
  ('456 Park Avenue', 'Delhi', 'Delhi', '+91-2345678901', 'info@prestigemotors.in'),
  ('789 Orchard Road', 'Bangalore', 'Karnataka', '+91-3456789012', 'info@elitewheels.co.in'),
  ('1010 Fifth Avenue', 'Kolkata', 'West Bengal', '+91-4567890123', 'info@luxemotors.co.in'),
  ('1111 Main Boulevard', 'Chennai', 'Tamil Nadu', '+91-5678901234', 'info@supremecars.co.in'),
  ('2222 Park Street', 'Hyderabad', 'Telangana', '+91-6789012345', 'info@autodrive.com'),
  ('3333 Bay Road', 'Pune', 'Maharashtra', '+91-7890123456', 'info@premiermotors.co.in'),
  ('4444 Lake View Drive', 'Ahmedabad', 'Gujarat', '+91-8901234567', 'info@luxuryrides.com'),
  ('5555 Ocean Avenue', 'Jaipur', 'Rajasthan', '+91-9012345678', 'info@prideautomobiles.in'),
  ('6666 Elm Street', 'Lucknow', 'Uttar Pradesh', '+91-1234567809', 'info@grandmotors.co.in');
